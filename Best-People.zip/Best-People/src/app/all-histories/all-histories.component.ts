import { Component, OnInit, Input } from '@angular/core';
import { Histories } from '../histories/histories.model';
import { HistoriesService } from '../histories/histories.service';
import { User } from '../user/user.model';
import { UserService } from '../user/user.service';

@Component({
  selector: 'all-histories',
  templateUrl: './all-histories.component.html',
  styleUrls: ['./all-histories.component.css']
})
export class AllHistoriesComponent implements OnInit {
  histories:Histories[];
  userList:User[];
  user:User;
 history:Histories;

  constructor(private historiesService:HistoriesService, 
    private userService:UserService) { }

  ngOnInit() {
    this.user = new User;
    this.history = new Histories();
    this.histories = new Array();
    
    

    this.historiesService.getHistories()
    .subscribe((data: Histories[]) => this.histories = data,
      error => console.error(error), () => console.log('My histories list is loaded!'));
      
      

  }
  
  

}
