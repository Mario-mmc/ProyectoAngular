import { Routes, RouterModule } from "@angular/router";
import { HistoriasComponent } from './HISTORIAS/historias.component';
import { AmigosComponent } from './AMIGOS/amigos.component';
import { ModuleWithProviders } from '@angular/core';
import { MisCosasComponent } from './MIS- COSAS/mis-cosas.component';
import { PeopleComponent } from './people/people.component';

const routes:Routes=[
    {path: '', component: MisCosasComponent},
    {path:'miscosas', component: MisCosasComponent},
    {path:'historias', component: HistoriasComponent},
    {path:'amigos', component: AmigosComponent},
    {path:'people', component: PeopleComponent}
]

export const routing:ModuleWithProviders = RouterModule.forRoot(routes);