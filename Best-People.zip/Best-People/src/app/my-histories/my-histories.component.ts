import { Component, OnInit } from '@angular/core';
import { HistoriesService } from '../histories/histories.service';
import { Histories } from '../histories/histories.model';
import { User } from '../user/user.model';
import { UserService } from '../user/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'my-histories',
  templateUrl: './my-histories.component.html',
  styleUrls: ['./my-histories.component.css']
})
export class MyHistoriesComponent implements OnInit {
    user:User;
    myHistories:Histories[];
    history: Histories;

            
  constructor(private historiesService:HistoriesService, private userService:UserService, private router:Router) { }

  ngOnInit() {
      this.myHistories = new Array();
      this.user = new User();
      this.history = new Histories();

    this.historiesService.getMainHistories()
      .subscribe((data: Histories[]) => this.myHistories = data,
        error => console.error(error), () => console.log('My histories list is loaded!'));

        this.userService.getMainUser().subscribe((data:User) => this.user = data,
        error => console.log('error'), () => console.log('Main User loaded!'));

    
  }
  getUsername():string{
    return this.user.name+' '+this.user.surname;
  }
  deleteHistory(history:Histories){
    this.historiesService.deleteHistory(history).subscribe((data:Histories) => this.history = data,
    error => console.log('error'), () => window.location.reload());
    
  }

  }
  



