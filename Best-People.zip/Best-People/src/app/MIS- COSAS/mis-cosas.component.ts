import { Component, OnInit } from '@angular/core';
import { User } from '../user/user.model';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-mis-cosas',
  templateUrl: './mis-cosas.component.html',
  styleUrls: ['./mis-cosas.component.css']
})
export class MisCosasComponent implements OnInit {
  userList:User[];
  

  constructor(private userService:UserService) { }

  ngOnInit() {
    this.userService.getUser()
    .subscribe((data:User[]) => this.userList = data,
    error => console.error(error), () => console.log('Relation List is loaded!'));
  }

}
