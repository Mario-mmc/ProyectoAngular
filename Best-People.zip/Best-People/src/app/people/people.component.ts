import { Component, OnInit } from '@angular/core';
import { User } from '../user/user.model';
import { UserService } from '../user/user.service';
import { Relationship } from '../relationship/relationship.model';
import { RelationshipService } from '../relationship/relationship.service';

@Component({
  selector: 'app-people',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.css']
})
export class PeopleComponent implements OnInit {
  userList:User[];
  people:User[];
  relation:Relationship;

  constructor(private userService:UserService,
    private relationshipService:RelationshipService) { }

  ngOnInit() {
    this.userList = new Array();
    this.relation = new Relationship();
    this.userService.getUser().subscribe((data: User[]) => this.userList = data,
    error => console.error(error), () => console.log('usuarios desde amigos estan cargados'));

    
  }

}
