import { Component, OnInit, Input } from '@angular/core';
import { RelationshipService } from './relationship.service';
import { UserService } from '../user/user.service';
import { User } from '../user/user.model';
import { Relationship } from './relationship.model';

@Component({
  selector: 'app-relationship',
  templateUrl: './relationship.component.html',
  styleUrls: ['./relationship.component.css']
})

export class RelationshipComponent implements OnInit {
  user: User;
  userName:string;
 @Input() user2: User;
  userList:User[];
  relationshipList: Relationship[];
  relation:Relationship;

  userextranyo:User[];
  constructor(private relationshipService: RelationshipService, private userService: UserService) { }

  ngOnInit() {
    this.user = new User();
    this.userName = '';
    this.user2 = new User();
    this.relation = new Relationship();
    this.userList = new Array();
    this.userextranyo = new Array();

    this.relationshipService.getMainRelationships().subscribe((data: Relationship[]) => this.relationshipList = data,
    error => console.error(error), () => console.log('Relation List is loaded!'));
    
    this.userService.getUser().subscribe((data: User[]) => this.userList = data,
    error => console.error(error), () => console.log('Relation List is loaded!'));

    // this.userService.getMainUser().subscribe((data: User) => this.user = data,
    // error => console.error(error), () => console.log('idUser1 is loaded!'));

    
  }


  acceptRelationship(relationship:Relationship, user:User){
    relationship.status="Friends";
    relationship.idUser1=this.user.id;
    relationship.idUser2= user.id;

    this.relationshipService.updateRelationShip(relationship)
    .subscribe(error => console.error(error), () =>window.location.reload);
  }

  sendRelationship(relationship:Relationship, user:User){
    relationship.status="Pending";
    relationship.idUser1=this.user.id;
    relationship.idUser2= user.id;

    this.relationshipService.addRelationship(relationship)
    .subscribe(error => console.error(error), () => window.location.reload);
  }

  declineRelationship(relationship:Relationship){

    this.relationshipService.deleteRelationship(relationship)
    .subscribe(error => console.error(error), () => window.location.reload);
  }
  
  
  

}
