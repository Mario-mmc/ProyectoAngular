import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user.model';
import { Observable } from 'rxjs';


const URL_BASE:string = 'http://localhost:3000/user';

const httpOptions ={
    headers: new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization':'my-auth-token'
    })
  };


@Injectable()
export class UserService {

  constructor(private http:HttpClient) { }

getUser(){
    return this.http.get('http://localhost:3000/User');
}
getMainUser(){
  return this.http.get('http://localhost:3000/User/1');
}

updateUser(user:User):Observable<User>{
  const url =`${URL_BASE}/${user.id}`;
  return this.http.put<User>(url, user, httpOptions);
 }

 addUser(user:User):Observable<User>{
  return this.http.post<User>(URL_BASE,user,httpOptions);
}
getUserById(idUser:number){
  return this.http.get(`http://localhost:3000/User/${idUser}`);
}

}
