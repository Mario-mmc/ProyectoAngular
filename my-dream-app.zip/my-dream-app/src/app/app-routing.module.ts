import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemListComponent } from './item-list/item-list.component';
import { OrderComponent } from './order/order.component';
import { ItemComponent } from './item/item.component';
import { ContactComponent } from './contact/contact.component';

const routes: Routes = [
  {path: '', component: ItemListComponent},
  {path:'order', component: OrderComponent},
  {path:'item/:id', component: ItemComponent},
  {path: 'contact', component: ContactComponent}
];
export const routing = RouterModule.forRoot(routes);

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
