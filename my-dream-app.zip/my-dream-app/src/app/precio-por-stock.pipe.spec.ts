import { PrecioPorStockPipe } from './precio-por-stock.pipe';

describe('PrecioPorStockPipe', () => {
  it('create an instance', () => {
    const pipe = new PrecioPorStockPipe();
    expect(pipe).toBeTruthy();
  });
});
