import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule, routing } from './app-routing.module';
import { AppComponent } from './app.component';
import { TotalPipe } from './total.pipe';
import { PrecioPorStockPipe } from './precio-por-stock.pipe';
import { ItemListComponent } from './item-list/item-list.component';
import { FormsModule } from '@angular/forms';
import { ItemListService } from './item-list/item-list-service';
import { HttpClientModule} from '@angular/common/http';
import { ItemComponent } from './item/item.component';
import { OrderComponent } from './order/order.component';
import { AddNewItemComponent } from './add-new-item/add-new-item.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { ContactComponent } from './contact/contact.component';
import { CartComponent } from './cart/cart.component';

@NgModule({
  declarations: [
    AppComponent,
    TotalPipe,
    PrecioPorStockPipe,
    ItemListComponent,
    ItemComponent,
    OrderComponent,
    AddNewItemComponent,
    NavMenuComponent,
    ContactComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    routing,
    FormsModule
    
  ],
  providers: [ItemListService, ItemComponent, ItemListComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
