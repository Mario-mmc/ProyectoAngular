import { Component, OnInit, Input, Output, Injectable } from '@angular/core';
import { Item } from '../item-list/shared/item.model';
import { EventEmitter } from 'events';
import { ItemListComponent } from '../item-list/item-list.component';
import { Router } from '@angular/router';



@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})

export class ItemComponent implements OnInit {

  @Input() item: Item;

  @Output() eventEmitter = new EventEmitter();
  

  
  constructor(private itemListComponent:ItemListComponent, private route:Router) { }

  ngOnInit() {
    
    // this.route.params.subscribe(params=>{
    //   const id =<string>params['id'];
    //    if(id != null){

    //    }
    //  });
  }

  deleteItem(event:EventEmitter){
   this.itemListComponent.deleteItem(this.item);
   
  }

  updateItem(event){
     return this.itemListComponent.updateItem(this.item);
  }
  addItem(item:Item){
    this.itemListComponent.addItem(item);
  
  }

  ocultar(item:Item){
    return this.itemListComponent.ocultar(item);
  }

  mostrar(event,item:Item){
    return this.itemListComponent.mostrar(event,item);
  
  }

  mouseEnter(event, item:Item){
    return this.itemListComponent.mouseEnter(event,item);
  }

  mouseLeave(event,item:Item){
    return this.itemListComponent.mouseLeave(event,item);
  }

  inputChanges(event, item:Item){
    return this.itemListComponent.inputChanges(event,item);
  }

  mouseOver(event,item:Item){
    return this.itemListComponent.mouseOver(event,item);
  }

  mouseOut(event, item:Item){
    return this.itemListComponent.mouseOut(event,item);
  }
  sumCantidad(item:Item){
    return this.itemListComponent.sumCantidad(item);
    }
   
  
  resCantidad(item:Item){
    return this.itemListComponent.resCantidad(item);
  }
  addToCart(item:Item){
    this.itemListComponent.addToCart(item);
    console.log('added');
  }
  deleteFromCart(item:Item){
    console.log('deleted');
    this.itemListComponent.deleteFromCart(item);
  }

  


}
