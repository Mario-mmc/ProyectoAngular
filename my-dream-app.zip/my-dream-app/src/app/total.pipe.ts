import { Pipe, PipeTransform, ɵɵelementContainerStart } from '@angular/core';
import {AppComponent} from './app.component';
import { isUndefined } from 'util';


@Pipe({
  name: 'total'
})
export class TotalPipe implements PipeTransform {

  transform(value:any, args:string): any {
    return value.reduce((prev, current)=> prev + current[args],0);
    
  }

}
