import { Component, OnInit } from '@angular/core';
import { Item } from '../item-list/shared/item.model';
import { ITEMCART } from './cart.mocks';
import { ItemComponent } from '../item/item.component';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  itemList:Item[]=ITEMCART;
  item:Item;
  

  constructor(private itemComponent:ItemComponent) { }

  ngOnInit() {
  this.item = new Item();
  this.itemList = new Array<Item>();
  }
addItemsSelected(){
}
  totalPriceByItem(item:Item){
    return item.price * item.quantity;
  }
  totalItemCart():number {

    let total: number = 0;
    if (total != undefined)
      this.itemList.forEach(element => {
        total = total + element.quantity;
      });

    return total;
  };
  addToCart(item:Item){
    if(item.addToCart == false){
      item.addToCart = true;
      this.itemList.push(item);
      
    }
  }
  deleteOfCart(item){
    if(item.addCart)
    item.addCart=false;
  }

}
