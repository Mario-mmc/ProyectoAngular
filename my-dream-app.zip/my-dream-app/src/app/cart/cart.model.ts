import { Item } from '../item-list/shared/item.model';

export class Cart{
    
    item:Item[];
    quantity:number;
}

