import { Component, OnInit } from '@angular/core';
import { Item } from '../item-list/shared/item.model';
import { ItemComponent } from '../item/item.component';
import { ItemListService } from '../item-list/item-list-service';




@Component({
  selector: 'add-new-item',
  templateUrl: './add-new-item.component.html',
  styleUrls: ['./add-new-item.component.css']
})
export class AddNewItemComponent implements OnInit {
    
  addItem:Item;
  hiddenForm:boolean;

  constructor(private itemComponent:ItemComponent, private itemlistService:ItemListService) {
    
   }

  ngOnInit() {
    this.addItem = new Item();
    this.addItem.quantity = 0;
    this.addItem.addToCart=false;
    this.hiddenForm = true;
    
    }

    mostrar(){
        this.hiddenForm = false;
      }

    ocultar(){
      this.hiddenForm = true;
    }
  

    addNewItem(item:Item){
      this.itemComponent.addItem(item);
      this.hiddenForm = true;
      return this.itemlistService.getItemList();
    
    }
  

  

  
}
  

