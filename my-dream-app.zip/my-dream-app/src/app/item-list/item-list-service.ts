import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Item } from './shared/item.model';






const URL_BASE:string = 'http://localhost:3000/item-list';

const httpOptions ={
    headers: new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization':'my-auth-token'
    })
};
@Injectable()
export class ItemListService{

    constructor(private http:HttpClient){}
   
    getItemList(){
        return this.http.get('http://localhost:3000/item-list');
    }
    
   updateItem(item:Item):Observable<Item>{
    const url =`${URL_BASE}/${item.id}`;
    return this.http.put<Item>(url, item, httpOptions);
   }

   deleteItem(item:Item):Observable<Item>{

    const url =`${URL_BASE}/${item.id}`;
    return this.http.delete<Item>(url);
   }
   
   addItem(item:Item):Observable<Item>{
        return this.http.post<Item>(URL_BASE,item,httpOptions);
   }
    

}