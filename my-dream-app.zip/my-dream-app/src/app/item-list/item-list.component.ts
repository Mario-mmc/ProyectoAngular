import { Component, OnInit } from '@angular/core';
import { Item } from './shared/item.model';
import { ItemListService } from './item-list-service';




@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})

export class ItemListComponent implements OnInit {
  myItem: Item[];
  newItem: Item;
  searchBar:string;
  itemHidden:boolean;



  //Sin el private no funciona, SIEMPRE hay que poner private. Los servicios SIEMPRE se ponen en el constructor, si queremos añadir mas servicios; entonces los ondremos separados con comas.
  constructor(private itemListService: ItemListService) { }

  ngOnInit(
    
  ) {
    this.itemHidden = false;
    this.searchBar = '*';

    this.itemListService.getItemList()
      .subscribe((data: Item[]) => this.myItem = data,
        error => console.error(error), () => console.log('My item list is loaded!'));
  }

  updateItem(item: Item) {

    this.itemListService.updateItem(item).subscribe();
    return this.itemListService.getItemList();
  }

  deleteItem(item: Item) {

    this.itemListService.deleteItem(item).subscribe();
    
    
  }

  addItem(item: Item) {
    item.addToCart = false;
    item.quantity = 0,
    item.selected = false;
    this.itemListService.addItem(item).subscribe(item => this.myItem.push(item));
  }

  totalItems(): number {

    let total: number = 0;
    if (total != undefined)
      this.myItem.forEach(element => {
        total = total + element.stock;
      });

    return total;
  };

  sumCantidad(item: Item) {
    if (item.stock !== 0) {
      item.quantity++;
      item.stock--;
    }
  }

  resCantidad(item: Item) {
    item.quantity--;
    item.stock++;
  }

  mouseOver(event, item: Item) {
    item.selected = true;
  }

  mouseOut(event, item: Item) {
    item.selected = false;
  }

  inputChanges(event, item: Item) {
    if (item.quantity >= 0) {
      item.selected = false;
    }

    else if (item.quantity <= item.stock) {
      item.selected = true;
    }

    else if (item.quantity > item.stock) {
      item.quantity = item.stock;
      item.stock = item.stock - item.quantity;
      item.selected = true;
    }

    item.stock = item.stock - item.quantity;
  }

  mouseEnter(event, item: Item) {
    item.selected = true;
  }

  mouseLeave(event, item: Item) {
    item.selected = false;
  }

  ocultar(item: Item) {
    item.dHidden = true;
  }

  mostrar(event, item: Item) {
    item.dHidden = false;
    this.updateItem(item);

  }
  addToCart(item:Item){
    item.addToCart = true;
  }
  deleteFromCart(item:Item){
    item.addToCart = false;
  }

  busqueda(item:Item){
    if(item.name == this.searchBar){
      item.selected = true;
    }else
    item.selected = false;
  }
 
  
  
 }
  
  





