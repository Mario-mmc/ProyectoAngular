import { Item.Model } from './item.model';

describe('Item.Model', () => {
  it('should create an instance', () => {
    expect(new Item.Model()).toBeTruthy();
  });
});
