import { Item } from "./shared/item.model";

export const ITEM:Item[]=[
    {
        "id": 1,
        "name": 'Carmen de Mairena',
        "description": 'El alma de las fiestas con sus originales pareados.',
        "stock":5,
        "price":149.99,
        "image":'assets/carmendemairena.jpg',
        "selected":false,
        "quantity":0
      },
      {
      "id":2,
      "name": 'Chucky de Cieza',
      "description":'Perfecto para intimidar a alguien que te delató.',
      "stock": 7,
      "price":200,
      "image":'assets/chuckydecieza.jpg',
      "selected":false,
      "quantity":0
      },
      {
        "id":3,
        "name":'Ares',
        "description":'Para tomarse con humor cuando la Guardia Civil te para en un control.',
        "stock": 0,
        "price":100,
        "image":'assets/pimpamtomalacasitos.png',
        "selected":false,
        "quantity":0
      },
      {
      "id":4,
      "name":'Leticia Sabater',
      "description":'Simplemente ámala',
      "stock":3,
      "price":1,
      "image":'assets/leticiasabater.jpeg',
      "selected":false,
      "quantity":0
      
        
      
}];